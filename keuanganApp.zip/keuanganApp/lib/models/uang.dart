class Laporan {
  final String uid;
  final String docId;

  final String namatrans;
  final String deskripsi;
  final String kategori;
  final String gambar;
  final String status;
  final DateTime tanggal;
  final String maps;
  List<Komentar>? komentar;

  Laporan({
    required this.uid,
    required this.docId,
    required this.namatrans,
    required this.deskripsi,
    required this.kategori,
    required this.gambar,
    required this.status,
    required this.tanggal,
    required this.maps,
    this.komentar,
  });
}

class Komentar {
  final String nama;
  final String isi;

  Komentar({
    required this.nama,
    required this.isi,
  });
}
