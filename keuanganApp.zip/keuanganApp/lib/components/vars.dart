import 'package:flutter/material.dart';
import 'package:keuanganApp/components/styles.dart';

List<String> dataStatus = ['Posted', 'Proses', 'Selesai'];
List<Color> warnaStatus = [warningColor, dangerColor, successColor];
List<String> dataKategori = ['Pekerjaan', 'Main', 'Kebutuhan Mendadak'];
