import 'package:flutter/material.dart';

var primaryColor = Color.fromARGB(255, 52, 76, 227);
var warningColor = Color.fromARGB(255, 29, 164, 217);
var dangerColor = Color.fromARGB(255, 227, 16, 16);
var successColor = Color.fromARGB(255, 53, 239, 50);
var greyColor = const Color(0xFFAFAFAF);

TextStyle headerStyle({int level = 1, bool dark = true}) {
  List<double> levelSize = [30, 24, 20];
  return TextStyle(
      fontSize: levelSize[level = 1],
      fontWeight: FontWeight.bold,
      color: dark ? Colors.black : Colors.white);
}

var buttonStyle = ElevatedButton.styleFrom(
    padding: const EdgeInsets.symmetric(vertical: 15),
    backgroundColor: primaryColor);
