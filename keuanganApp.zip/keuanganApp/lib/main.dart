import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:keuanganApp/firebase_options.dart';
import 'package:keuanganApp/pages/AddFormPage.dart';
import 'package:keuanganApp/pages/Detailpage.dart';
import 'package:keuanganApp/pages/SplashPage.dart';
import 'package:keuanganApp/pages/UpdateLaporan.dart';
import 'package:keuanganApp/pages/dashboard/DashboardPage.dart';
import 'package:keuanganApp/pages/LoginPage.dart';
import 'package:keuanganApp/pages/RegisterPage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(MaterialApp(
    title: 'KeuanganApp',
    initialRoute: '/',
    routes: {
      '/': (context) => const SplashFull(),
      '/login': (context) => const LoginPage(),
      '/register': (context) => const RegisterPage(),
      '/dashboard': (context) => const DashboardPage(),
      '/add': (context) => const AddFormPage(),
      '/detail': (context) => const DetailPage(),
      '/update': (context) => const updatePage(),
    },
  ));
}
