package com.example.lapor_book

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
